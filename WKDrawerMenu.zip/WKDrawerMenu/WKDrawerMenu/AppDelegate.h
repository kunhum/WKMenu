//
//  AppDelegate.h
//  WKDrawerMenu
//
//  Created by Nicholas on 16/2/25.
//  Copyright © 2016年 Nicholas. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

