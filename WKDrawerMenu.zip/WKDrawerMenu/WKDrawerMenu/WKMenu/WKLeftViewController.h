//
//  WKLeftViewController.h
//  WKDrawerMenu
//
//  Created by Nicholas on 16/2/25.
//  Copyright © 2016年 Nicholas. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WKLeftViewController : UIViewController

//菜单标题
@property (nonatomic,strong)NSMutableArray *titles;
//菜单各选项的控制器
@property (nonatomic,strong)NSMutableArray *viewControllers;

@end
