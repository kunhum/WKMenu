//
//  WKMenuViewController.h
//  WKDrawerMenu
//
//  Created by Nicholas on 16/2/25.
//  Copyright © 2016年 Nicholas. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WKMenuViewController : UIViewController

//根视图控制器
@property (nonatomic,strong)UIViewController *rootViewController;
//左侧菜单控制器
@property (nonatomic,strong)UIViewController *leftViewController;
//判定打开的幅度,默认为0.5 [0.0-1.0]
@property (nonatomic,assign)CGFloat openProgress;
//判定关闭的幅度，默认为0.5 [0.0-1.0]
@property (nonatomic,assign)CGFloat closeProgress;
//控制打开的宽度,默认为250
@property (nonatomic,assign)CGFloat openWidth;
//当前菜单的开关状态
@property (nonatomic,assign)BOOL isDisplaying;
//菜单开关的速度,默认为0.6
@property (nonatomic,assign)CGFloat switchSpeed;

//设置菜单按钮图标
- (void)setMenuButtonIcon:(UIImage *)image;

//关闭菜单
- (void)closeMenu;

//创建管理控制器
+ (instancetype)shareWKMenuViewController;

@end
