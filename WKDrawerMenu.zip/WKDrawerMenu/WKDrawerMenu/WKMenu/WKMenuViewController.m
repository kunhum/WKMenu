//
//  WKMenuViewController.m
//  WKDrawerMenu
//
//  Created by Nicholas on 16/2/25.
//  Copyright © 2016年 Nicholas. All rights reserved.
//

#import "WKMenuViewController.h"

@interface WKMenuViewController ()<UIGestureRecognizerDelegate>

@property (nonatomic,strong)UIScreenEdgePanGestureRecognizer *screenEdgePanGuesture;
@property (nonatomic,strong)UIPanGestureRecognizer *panGuesture;
@property (nonatomic,strong)UITapGestureRecognizer *tapGuesture;
@property (nonatomic,strong)UIScreenEdgePanGestureRecognizer *left;

@property (nonatomic,strong)UIButton *leftButton;

@property (nonatomic,assign)CGFloat speed;
@property (nonatomic,assign)BOOL first;

@end

@implementation WKMenuViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.first = YES;
    
    self.view.backgroundColor = [UIColor whiteColor];
    
}

+ (instancetype)shareWKMenuViewController{
    static WKMenuViewController *menuVC = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        menuVC = [[WKMenuViewController alloc]init];
    });
    return menuVC;
}


//左侧菜单
- (void)setLeftViewController:(UIViewController *)leftViewController{
    
    _leftViewController = leftViewController;
    
    if (_leftViewController) {
        
        CGRect frame = self.view.frame;
        if (!self.openWidth) {
            self.openWidth = 250;
        }
        frame.size.width = self.openWidth;
        _leftViewController.view.frame = frame;
        
        if (_rootViewController) {
            
            [self.view insertSubview:_leftViewController.view belowSubview:_rootViewController.view];
        }
        
    }
}

//根控制器
- (void)setRootViewController:(UIViewController *)rootViewController{
    
    if (_rootViewController) {
        [_rootViewController.view removeFromSuperview];
    }
    _rootViewController = rootViewController;
    
    if (_rootViewController) {
        
        UIView *menuView = _rootViewController.view;
        CGRect frame = self.view.bounds;
        if (self.first) {
            menuView.frame = frame;
        }
        else{
            menuView.frame = CGRectMake(self.openWidth, 0, self.view.bounds.size.width, self.view.bounds.size.height);
        }
        
        [self.view addSubview:menuView];
        
        if (_leftViewController && self.first) {
            
            [self.view insertSubview:_leftViewController.view belowSubview:_rootViewController.view];
        }
        self.first = NO;
    }
    
    [self setDefaultDate];
    
}

//配置默认数据
- (void)setDefaultDate{
    
    if (self.rootViewController.view.frame.origin.x != 0) {
        self.isDisplaying = YES;
    }
    else{
        self.isDisplaying = NO;
    }
    if (!self.openProgress) {
        self.openProgress = 0.5;
    }
    if (!self.openWidth) {
        self.openWidth = 250;
    }
    if (!self.switchSpeed) {
        self.switchSpeed = 0.6;
    }
    if (!self.closeProgress) {
        self.closeProgress = 0.5;
    }
    
    [self addGestureRecognize];
    [self setDefaultImageForNavigationButton];
    
}
#pragma mark 为导航栏按钮设置默认图片
- (void)setDefaultImageForNavigationButton{
    //为导航栏设置默认图片
    self.leftButton = [UIButton buttonWithType:UIButtonTypeSystem];
    self.leftButton.frame = CGRectMake(8, 10, 30, 30);
    [self.leftButton setImage:[[UIImage imageNamed:@"menu16"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] forState:UIControlStateNormal];
    [self.leftButton addTarget:self action:@selector(leftButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    
    //判断根视图控制器是否为导航控制器
    if ([self.rootViewController isKindOfClass:[UINavigationController class]]) {
        //先拿到导航控制器
        UINavigationController *navC = (UINavigationController*)self.rootViewController;
        //获取导航栏下的控制器
        NSArray *viewControllers = navC.viewControllers;
        UIViewController *viewController = viewControllers[0];
        //添加按钮
        [viewController.navigationController.navigationBar addSubview:self.leftButton];
    }
}
- (void)leftButtonAction:(UIButton *)leftButton{
    
    if (self.isDisplaying == NO) {
        
        [self openOperation];
        
    }else{
        
        [self closeOperation];
        
    }
    
}

#pragma mark 添加手势
- (void)addGestureRecognize{
    //添加手势
    //边缘
    self.screenEdgePanGuesture = [[UIScreenEdgePanGestureRecognizer alloc]initWithTarget:self action:@selector(handleScreenEdgePan:)];
    self.screenEdgePanGuesture.edges = UIRectEdgeLeft;
    [self.rootViewController.view addGestureRecognizer:self.screenEdgePanGuesture];
    
    //点击
    self.tapGuesture = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(handleTap:)];
    [self.rootViewController.view addGestureRecognizer:self.tapGuesture];
    
    //平移
    self.panGuesture = [[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(handlePan:)];
    self.panGuesture.delegate = self;
    [self.rootViewController.view addGestureRecognizer:self.panGuesture];
}
#pragma mark 手势识别(对平移手势加代理来达到识别手势的效果)
- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer{
    
    if (self.isDisplaying) {
        return YES;
    }else{
        return NO;
    }
}

//边缘
- (void)handleScreenEdgePan:(UIGestureRecognizer *)recognizer{
    
    [self handleGuestureRecognizer:recognizer];
}
//点击
- (void)handleTap:(UIGestureRecognizer *)recognizer{
    
    if (self.isDisplaying) {
        
        [self closeOperation];
        
    }
    
}
//平移
- (void)handlePan:(UIGestureRecognizer *)recognizer{
    
    
    if (self.isDisplaying) {
        
        [self handleGuestureRecognizer:recognizer];
        
    }

}

- (void)handleGuestureRecognizer:(UIGestureRecognizer *)recognizer{
    
    //打开的百分比
    CGFloat progress = [recognizer locationInView:self.leftViewController.view].x / self.openWidth;
    
    
    //手势当前的位置
    CGPoint movePoint = [recognizer locationInView:self.rootViewController.view];
    
    if (recognizer.state == UIGestureRecognizerStateChanged && progress >= 0.0 && progress <= 1.0) {
        
        self.rootViewController.view.frame = CGRectMake(self.rootViewController.view.frame.origin.x + movePoint.x, 0, self.view.bounds.size.width, self.view.bounds.size.height);
        
    }
    else if (recognizer.state == UIGestureRecognizerStateEnded){//手势结束的时候
        //如果是边缘手势
        if ([recognizer isKindOfClass:[UIScreenEdgePanGestureRecognizer class]] && progress >= self.openProgress) {
            //大于设定的百分比就打开
            
            [self openOperation];
            
        }
        //如果不是边缘手势
        else if(![recognizer isKindOfClass:[UIScreenEdgePanGestureRecognizer class]] && 1.0-progress <= self.closeProgress){
            
            [self openOperation];
            
        }
        else{
            
            if ([recognizer isKindOfClass:[UIScreenEdgePanGestureRecognizer class]]) {
                [self closeOperation];
            }
            else if ([recognizer isKindOfClass:[UIPanGestureRecognizer class]] && 1.0 - progress >= self.closeProgress){
                [self closeOperation];
            }
            
        }
        
    }
    
}

- (void)openOperation{
    
    CGRect frame = self.view.bounds;
    frame.origin.x = self.openWidth;
    [UIView animateWithDuration:self.switchSpeed animations:^{
        self.rootViewController.view.frame = frame;
    }];
    
    self.isDisplaying = YES;
    
}

- (void)closeOperation{
    
    CGRect frame = self.view.bounds;
    
    [UIView animateWithDuration:self.switchSpeed animations:^{
        self.rootViewController.view.frame = frame;
    }];
    
    self.isDisplaying = NO;
}

#pragma mark 设置菜单开关按键图片
- (void)setMenuButtonIcon:(UIImage *)image{
    if (image) {
        
        [self.leftButton setImage:[image imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] forState:UIControlStateNormal];
        
    }
}

#pragma mark 关闭菜单
- (void)closeMenu{
    
    if (self.isDisplaying) {
    
        [self closeOperation];
        
    }
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
