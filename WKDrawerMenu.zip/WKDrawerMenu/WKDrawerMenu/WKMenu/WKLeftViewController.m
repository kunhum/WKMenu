//
//  WKLeftViewController.m
//  WKDrawerMenu
//
//  Created by Nicholas on 16/2/25.
//  Copyright © 2016年 Nicholas. All rights reserved.
//

#import "WKLeftViewController.h"
#import "WKMenuViewController.h"

@interface WKLeftViewController ()<UITableViewDataSource,UITableViewDelegate>

@property (nonatomic,strong)UITableView *tableView;

@end

static NSString *cellFlag = @"tableViewCell";

@implementation WKLeftViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 22, self.view.bounds.size.width, self.view.bounds.size.height-22) style:UITableViewStylePlain];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:cellFlag];
    [self.view addSubview:self.tableView];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.titles.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellFlag forIndexPath:indexPath];
    
    cell.textLabel.text = self.titles[indexPath.row];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    WKMenuViewController *menuVC = [WKMenuViewController shareWKMenuViewController];
    UINavigationController *navC = [[UINavigationController alloc]initWithRootViewController:self.viewControllers[indexPath.row]];
    menuVC.rootViewController = navC;
    [menuVC closeMenu];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
