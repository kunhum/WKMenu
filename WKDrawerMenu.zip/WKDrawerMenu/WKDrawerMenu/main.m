//
//  main.m
//  WKDrawerMenu
//
//  Created by Nicholas on 16/2/25.
//  Copyright © 2016年 Nicholas. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
